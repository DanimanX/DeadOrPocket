Place Sega Model 2 / 2A-CRX .rom packages in Assets/model2/common/.
Phase 1 includes a built-in 3D Hardware Self-Test that runs without ROMs.
